from django.apps import AppConfig


class PackageInfoConfig(AppConfig):
    name = 'package_info'
