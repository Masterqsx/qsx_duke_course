This is the ups assignment for:
Shengxin Qian sq16
Jie Wang jw505
