1. The proxy will open on port 8000

2. This code is for Shengxin Qian and Yuhao Zhang