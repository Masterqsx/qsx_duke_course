#include <stdio.h>
#include "query_funcs.h"

#ifndef _EXERCISER_
#define _EXERCISER_


void exercise(MYSQL *conn);


#endif //_EXERCISER_       
