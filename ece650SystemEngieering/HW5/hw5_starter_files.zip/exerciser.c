#include "exerciser.h"

void exercise()
{

}
