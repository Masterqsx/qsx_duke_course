function res = linearkernel(data1, data2)
    res = data1 * data2';
end